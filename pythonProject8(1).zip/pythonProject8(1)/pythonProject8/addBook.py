from tkinter import *
from tkinter import messagebox
import sqlite3

con = sqlite3.connect('library.db')
cur = con.cursor()

class AddBook(Toplevel):
    def __init__(self):
     Toplevel.__init__(self)
     self.geometry("400x400+550+200")
     self.title("Add book")
     self.resizable(False,False)

#FRAME#

#Top frame

     self.topFrame = Frame(self, height=70, bg="#8B7D6B")
     self.topFrame.pack(fill=X)

#bottom frame
     self.bottomFrame = Frame(self, height=330, bg="#F5F5DC")
     self.bottomFrame.pack(fill=X)


#heading,date
     heading = Label(self.topFrame, text="Add Book", font="times 20 bold",bg="#8B7D6B")
     heading.place(x=130, y=10)


#Entries, labels
     #name
     self.lbl_name = Label(self.bottomFrame, text="Name:", font="times 15 bold", bg="#F5F5DC")
     self.lbl_name.place(x=40, y=40)
     self.ent_name = Entry(self.bottomFrame, width=30, bd=4)
     self.ent_name.insert(0,"Please enter a book name")
     self.ent_name.place(x=150, y=45)

     #author
     self.lbl_author = Label(self.bottomFrame, text="Author:", font="times 15 bold", bg="#F5F5DC")
     self.lbl_author.place(x=40, y=80)
     self.ent_author = Entry(self.bottomFrame, width=30, bd=4)
     self.ent_author.insert(0, "Please enter an author")
     self.ent_author.place(x=150, y=85)

     #page
     self.lbl_page = Label(self.bottomFrame, text="Page:", font="times 15 bold", bg="#F5F5DC")
     self.lbl_page.place(x=40, y=120)
     self.ent_page = Entry(self.bottomFrame, width=30, bd=4)
     self.ent_page.insert(0, "Please enter a page size")
     self.ent_page.place(x=150, y=125)

     #Button
     button= Button(self.bottomFrame, text="Add Book", bg="#8B7D6B",fg="white",command=self.addBook)
     button.place(x=160, y=210)

    def addBook(self):
         name = self.ent_name.get()
         author = self.ent_author.get()
         page = self.ent_page.get()

         if(name and author and page !=""):
             try:
                 query="INSERT INTO 'books' (Name, Author, page) VALUES(?, ?, ?)"
                 cur.execute(query,(name, author, page))
                 con.commit()
                 messagebox.showinfo("Success","Successfully added",icon='info')


             except:
                 messagebox.showinfo("Error", "Can not add to database", icon='warning')

         else:
             messagebox.showinfo("Error", "Fields can not be empty", icon='warning')


