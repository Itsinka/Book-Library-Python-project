from tkinter import *
from tkinter import ttk
import sqlite3
import addBook, addmember, giveBook
from tkinter import messagebox

con = sqlite3.connect("library.db")
cur = con.cursor()

class Main(object):
    def __init__(self, master):
        self.master = master

        def displayStatistics(evt):
            count_books=cur.execute("SELECT count (book_id) FROM books").fetchall()
            count_member= cur.execute("SELECT count (ID) FROM member").fetchall()
            taken_books = cur.execute("SELECT  count(status) FROM books WHERE status=1").fetchall()
            print(count_books)
            self.lbl_book_count.config(text='Total:'+str(count_books[0][0])+'books in library')
            self.lbl_members_count.config(text="Total member : " + str(count_member[0][0]))
            self.lbl_taken_count.config(text="Taken books :"+ str(taken_books[0][0]))
            displayBooks(self)

        def displayBooks(self):
            books = cur.execute("SELECT * FROM books").fetchall()
            count = 0

            self.list_book.delete(0,END)
            for book in books:
                print(book)
                self.list_book.insert(count, str(book[0]) + "-" + book[1])
                count += 1

            def bookInfo(evt):
                value = str(self.list_book.get(self.list_book.curselection()))
                id = value.split('-')[0]
                book = cur.execute("SELECT * FROM books WHERE book_id=?",(id,))
                book_info = book.fetchall()
                print(book_info)
                self.list_details.delete(0,'end')

                self.list_details.insert(0,"Book Name : "+book_info[0][1])
                self.list_details.insert(1,"Author : "+book_info[0][2])
                self.list_details.insert(2,"Page : "+book_info[0][3])
                if book_info[0][4] == 0:
                    self.list_details.insert(4,"Status : Available")
                else:
                    self.list_details.insert(4,"Status : Not Available")


            def doubleClick(evt):
                global given_id
                value = str(self.list_book.get(self.list_book.curselection()))
                given_id =value.split("-")[0]
                give_book = GiveBook()

            self.list_book.bind('<<ListboxSelect>>',bookInfo)
            self.tabs.bind('<<NotebookTabChanged>>',displayStatistics)
            #self.tabs.bind('<ButtonRelease-1>',displayBooks)
            self.list_book.bind("<Double-Button-1>", doubleClick)



        mainFrame = Frame(self.master)
        mainFrame.pack()
        topFrame = Frame(mainFrame, width=1500, height=600, bg="#F5F5DC", padx=20, relief=SUNKEN, borderwidth=2)
        topFrame.pack(side=TOP, fill=X)

        centerFrame = Frame(mainFrame, width=1500, relief=RIDGE, bg="#8B7D6B", height=700)
        centerFrame.pack(side=TOP)

        centerLeftFrame = Frame(centerFrame, width=900, height=600, bg="#8B7D6B", borderwidth=2, relief="sunken")
        centerLeftFrame.pack(side=LEFT)

        centerRightFrame = Frame(centerFrame, width=600, height=600, bg="#FFE4C4", borderwidth=2, relief="sunken")
        centerRightFrame.pack()

        #Search bar
        search_bar = LabelFrame(centerRightFrame, width=440, height=70, bg="#F5F5DC")
        search_bar.pack(fill=BOTH)
        self.lbl_search = Label(search_bar, text="Search:", font="times 10 bold", bg="#F5F5DC", fg='black')
        self.lbl_search.grid(row=0, column=0, padx=20, pady=10)
        self.ent_search = Entry(search_bar, width=20, bd=10)
        self.ent_search.grid(row=0, column=1, columnspan=2, padx=5, pady=5)
        self.btn_search = Button(search_bar, text="Find", font="times 10", bg="#8B7D6B", fg="white",
                                 command=self.searchBooks)
        self.btn_search.grid(row=0, column=3, padx=10, pady=10)

        #list bar
        list_bar = LabelFrame(centerRightFrame, width=440, height=170, bg="#F5F5DC")
        list_bar.pack(fill=BOTH)
        lbl_list = Label(list_bar, text=" Sort by:", font='times 16 bold', fg='#8B7D6B', bg='#F5F5DC')
        lbl_list.grid(row=0,column=0)
        self.listChoice = IntVar()
        rb1 = Radiobutton(list_bar, text='All Books', var=self.listChoice, value=1, bg="#F5F5DC")
        rb2 = Radiobutton(list_bar, text='In library', var=self.listChoice, value=2, bg="#F5F5DC")
        rb3 = Radiobutton(list_bar, text='Borrowed Books', var=self.listChoice, value=3, bg="#F5F5DC")
        rb1.grid(row=1, column=0)
        rb2.grid(row=1, column=1)
        rb3.grid(row=1, column=2)
        btn_list = Button(list_bar, text="list", bg="#8B7D6B", fg='white', font='times 10', command=self.listBooks)
        btn_list.grid(row=2, column=2, padx=40, pady=10)


        #image
        lib_bar = Frame(centerRightFrame, width=400, height=600)
        lib_bar.pack(fill=BOTH)
        self.img_library = PhotoImage(file="icons/library.png")
        self.lblImg = Label(lib_bar,image=self.img_library)
        self.lblImg.grid(row=0)




        # add member button
        self.iconmember = PhotoImage(file="icons/users.png")
        self.btnmember = Button(topFrame, bg="#8B7D6B", padx=5)
        self.btnmember.configure(image=self.iconmember, height=18, compound=LEFT,command=self.addMember)
        self.btnmember.pack(side=LEFT)

        #title

        #add book
        self.iconbook = PhotoImage(file='icons/add.png')
        self.btnbook = Button(topFrame,bg="#8B7D6B", image=self.iconbook, height=18, compound=LEFT,command=self.addBook)
        self.btnbook.pack(side=LEFT, padx=5)


        #give book
        self.icongive=PhotoImage(file="icons/givebook.png")
        self.btngive=Button(topFrame, text="Give Book", bg="#8B7D6B", fg="white", font="times 10", width=90, height=18, padx=10,image=self.icongive, compound=LEFT,command=self.giveBook)
        self.btngive.pack(side=LEFT)


        ##TABS##
        #Tab1
        self.tabs = ttk.Notebook(centerLeftFrame, width=900, height=600)
        self.tabs.pack()
        self.tab1_icon = PhotoImage(file="icons/management.png")
        self.tab2_icon = PhotoImage(file="icons/static.png")
        self.tab1 = ttk.Frame(self.tabs)
        self.tab2 = ttk.Frame(self.tabs)
        self.tabs.add(self.tab1, text="Management Library", image=self.tab1_icon, compound=LEFT)
        self.tabs.add(self.tab2, text="Statistics", image=self.tab2_icon, compound=LEFT)

        #list books
        self.list_book = Listbox(self.tab1, width=60, height=50, bd=5, font="times 12 bold")
        self.sb = Scrollbar(self.tab1, orient=VERTICAL)
        self.list_book.grid(row=0, column=0, padx=(10, 0), pady=10, sticky=N)
        self.sb.config(command=self.list_book.yview)
        self.list_book.config(yscrollcommand=self.sb.set)
        self.sb.grid(row=0, column=0, sticky=N+S+E)

        #detail
        self.list_details = Listbox(self.tab1, width=80, height=40, bd=5, font="times 12 bold")
        self.list_details.grid(row=0, column=1, padx=(10, 0), pady=10, sticky=N)
        self.lbl_book_count = Label(self.tab2, text="", pady=30, font="times 12 bold")
        self.lbl_book_count.grid(row=0)
        self.lbl_members_count = Label(self.tab2, text="", pady=30, font="times 12 bold")
        self.lbl_members_count.grid(row=1, sticky=W)
        self.lbl_taken_count = Label(self.tab2, text="", pady=30, font="times 12 bold")
        self.lbl_taken_count.grid(row=2, sticky=W)

        #functions
        displayBooks(self)
        displayStatistics(self)

    def addBook(self):
        add = addBook.AddBook()

    def addMember(self):
        member = addmember.AddMember()
    def searchBooks(self):
        value= self.ent_search.get()
        search= cur.execute("SELECT*FROM books where name LIKE ?",('%'+value+'%',)).fetchall()
        print(search)
        self.list_book.delete(0,END)
        count=0
        for book in search:
            self.list_book.insert(count,str(book[0])+"-"+book[1])
            count +=1
    def listBooks(self):
        value = self.listChoice.get()
        if value == 1:
            allbooks= cur.execute("SELECT *FROM books").fetchall()
            self.list_book.delete(0,END)

            count=0
            for book in allbooks:
                self.list_book.insert(count,str(book[0])+"-"+book[1])
                count += 1
        elif value ==2:
            books_in_library = cur.execute("SELECT * FROM books WHERE status=?",(0,)).fetchall()
            self.list_book.delete(0, END)

            count = 0
            for book in books_in_library:
                self.list_book.insert(count, str(book[0]) + "-" + book[1])
            count += 1
        else:
            taken_books = cur.execute("SELECT * FROM books WHERE status =?",(1,)).fetchall()
            self.list_book.delete(0, END)

            count = 0
            for book in taken_books:
                self.list_book.insert(count, str(book[0]) + "-" + book[1])
            count += 1



    def giveBook(self):
        give_book = giveBook.GiveBook()

class GiveBook(Toplevel):
    def __init__(self):
        Toplevel.__init__(self)
        self.geometry("400x400+550+200")
        self.title("Lend Book")
        self.resizable(False, False)
        global  given_id
        self.book_id = int(given_id)
        query = "SELECT * FROM books"
        books = cur.execute(query).fetchall()
        book_list = []
        for book in books:
            book_list.append(str(book[0]) + "-" + book[1])


        query2 = "SELECT * FROM member"
        members = cur.execute(query2).fetchall()
        member_list=[]
        for member in members:
            member_list.append(str(member[0]) + "-" + member[1])

        # Top frame

        self.topFrame = Frame(self, height=70, bg="#8B7D6B")
        self.topFrame.pack(fill=X)

        # bottom frame
        self.bottomFrame = Frame(self, height=330, bg="#F5F5DC")
        self.bottomFrame.pack(fill=X)

        # heading,date
        heading = Label(self.topFrame, text="Add Member", font="times 20 bold", bg="#8B7D6B")
        heading.place(x=110, y=10)

        # Entries, labels
        # name
        self.book_name = StringVar()
        self.lbl_name = Label(self.bottomFrame, text="Book name:", font="times 15 bold", bg="#F5F5DC")
        self.lbl_name.place(x=40, y=40)
        self.combo_name = ttk.Combobox(self.bottomFrame, textvariable=self.book_name)
        self.combo_name["values"] = book_list
        self.combo_name.current(self.book_id-1)
        self.combo_name.place(x=150,y=45)

        # phone
        self.member_name = StringVar()
        self.lbl_phone = Label(self.bottomFrame, text="Member :", font="times 15 bold", bg="#F5F5DC")
        self.lbl_phone.place(x=40, y=80)
        self.combo_member = ttk.Combobox(self.bottomFrame, textvariable=self.member_name)
        self.combo_member["values"] = member_list
        self.combo_member.place(x=150, y=85)

        # Button
        button = Button(self.bottomFrame, text="Lend Book", bg="#8B7D6B", fg="white", command=self.lendBook)
        button.place(x=160, y=210)

    def lendBook(self):
        book_name =self.book_name.get()
        member_name= self.member_name.get()

        if(book_name and member_name !=""):
            try:
                query = "INSERT INTO 'borrows' (book_id,member_id) VALUES(?,?)"
                cur.execute(query,(book_name,member_name))
                con.commit()
                messagebox.showinfo("Success", "Successfully added", icon="info")
                cur.execute("UPDATE book SET status =? WHERE book_id=?", (1, self.book_id))
                con.commit()
            except:
                messagebox.showinfo("Error", "Can not add", icon="warning")

        else:
            messagebox.showinfo("Error", "Fields can not be empty", icon="warning")

def main():
    root = Tk()
    app = Main(root)
    root.title("Library Management System")
    root.geometry("1200x650+400+300")
    root.mainloop()

if __name__== '__main__':
   main()
